let xCars=[600,600,600,600,600,600]
let yCars=[44,100,155,215,265,320]
let speedCars=[11,10,5,6,7,8]
let carLength=50
let carHeight=35

function show_Car(x,y,z){
  for (let i=0; i<image_Cars.length; i+=1){
  image(image_Cars[i],xCars[i],yCars[i],carLength,carHeight);
  }
}
function move_Car(){
  for(let i=0; i<image_Cars.length; i+=1){
  xCars[i]-=speedCars[i];
}
}
function return_Inition_Position(){
  for (let i=0; i<image_Cars.length; i+=1)
  if (hit_Border(xCars[i])){
    xCars[i]=600;
  }
}
function hit_Border(xCar){
  return xCar<-50; 
}