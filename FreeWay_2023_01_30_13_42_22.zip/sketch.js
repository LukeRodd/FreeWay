
function setup() {
  createCanvas(500,400);
  thrill_Sound.loop()
}

function draw() {
  background(image_HighWay);
  show_Actor()
  show_Car(car_1,xCars[0],yCars[0])
  show_Car(car_2,xCars[1],yCars[1])
  show_Car(car_3,xCars[2],yCars[2])
  move_Car()
  move_Actor()
  return_Inition_Position()
  verify_Colision()
  show_Actor_Points()
  mark_Points()
}
