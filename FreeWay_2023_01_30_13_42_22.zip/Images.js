//var images
let image_HighWay;
let main_Character;
let car_1;
let car_2;
let car_3;

//var sounds 
let colision_Sound
let points_Sound
let thrill_Sound

function preload(){
  image_HighWay=loadImage("Images/estrada.png")
  main_Character=loadImage("Images/ator-1.png")
  car_1=loadImage("Images/carro-1.png")
  car_2=loadImage("Images/carro-2.png")
  car_3=loadImage("Images/carro-3.png")
  image_Cars=[car_1,car_2,car_3,car_1,car_2,car_3]
  colision_Sound=loadSound("sound/colidiu.mp3")
  points_Sound=loadSound("sound/pontos.wav")
  thrill_Sound=loadSound("sound/trilha.mp3")
}