//var actor 
let xActor=245
let yActor=365;
let actorPoints=0;
let actorColision=false;

function show_Actor(){
  image(main_Character,xActor,yActor,30,30)
}
function move_Actor(){
  if (keyIsDown(UP_ARROW)){
    yActor-=3
  }
  if (keyIsDown(DOWN_ARROW)){
    if(canActorMove()){
    yActor+=3
    }
  }
  if (keyIsDown(RIGHT_ARROW)){
    xActor+=3
  }
  if (keyIsDown(LEFT_ARROW)){
    xActor-=3
  }
}
function verify_Colision(){
  for (let i=0; i<image_Cars.length;i+=1){
actorColision=collideRectCircle(xCars[i],yCars[i],carLength,carHeight,xActor,yActor,15)
    if (actorColision){
       back_Actor()
      colision_Sound.play()
      if (pointsZero()){
        actorPoints-=1
      }
    }
  }
}
function back_Actor(){
  xActor=245
  yActor=365
}
function show_Actor_Points(){
  textAlign(CENTER)
  textSize(30)
  fill(color(102,0,102))
  text(actorPoints, width/5,30)
}
function mark_Points(){
  if(yActor<15){
    back_Actor()
    points_Sound.play()
    actorPoints+=1
     }
}
function pointsZero(){
  return actorPoints>0
}
function canActorMove(){
  return yActor<366;
}